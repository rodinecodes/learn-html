export const rentHouses = [
  {
    id: 1,
    mainImage: "/Rent-houses/House-1/home1-1.jpg",

    name: "House in Lahore",
    price: "PKR 43,000,000",
  },
  {
    id: 2,
    mainImage: "/Rent-houses/House-2/home2-1.jpg",

    name: "House in Karachi",
    price: "PKR 10,000,000",
  },
  {
    id: 3,
    mainImage: "/Rent-houses/House-3/home3-1.jpg",

    name: "Flat in Karachi",
    price: "PKR 10,500,000",
  },
  {
    id: 4,
    mainImage: "/Rent-houses/House-4/home4-1.jpg",

    name: "Flat in Islamabad",
    price: "PKR 13,500,000",
  },
  {
    id: 5,
    mainImage: "/Rent-houses/House-5/home5-1.jpg",

    name: "House in Faisalabad",
    price: "PKR 19,500,000",
  },
  {
    id: 6,
    mainImage: "/Rent-houses/House-6/home6-1.jpg",

    name: "House in Karachi",
    price: "PKR 20,500,000",
  },
];
