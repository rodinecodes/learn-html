export const partnerBrands = [
  {
    title: "Grafton",
    src: "grafton",
  },
  {
    title: "Lighthouse",
    src: "lighthouse",
  },
  {
    title: "Tundratown",
    src: "tundratown",
  },
  {
    title: "Synero",
    src: "synero",
  },
  {
    title: "Tectus",
    src: "tectus",
  },
  {
    title: "Aeternus",
    src: "aeternus",
  },
];
