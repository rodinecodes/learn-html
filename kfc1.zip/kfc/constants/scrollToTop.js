export const scrollToTop = () => {
  window.scrollTo({ top: 0 });
};
