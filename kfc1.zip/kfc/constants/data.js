import pdt from"./product.jpeg";
import pdt1 from"./product1.jpeg";
import pdt2 from"./product2.jpeg";
import pdt3 from"./product3.jpeg";
import pdt5 from"./product4.jpeg";
import pdt6 from"./product6.jpeg";
import pdt7 from"./product7.jpeg";
import pdt8 from"./product8.jpeg";
import pdt9 from"./product9.jpeg";
import pdt10 from"./product10.jpeg";
import pdt4 from"./product4.jpeg";
import pdt21 from"./product21.jpeg";



export const rentHouses = [
  {
    id: 1,
    type: "Discounted price",
    mainImage: pdt1,
    moreImages: [
      pdt1,
      pdt1
    ],
    name: "wings with pepsi",
    address: "Kampala, mukono, Uganda",
    price: 20000,
    details: [
      "4 wings",
      "1 plate of chips",
      "5 thighs",
    ],
    description:
    "it comes with chilli & ketchup",
  },
  {
    id: 2,
    type: "Hot",
    mainImage: pdt8,
    moreImages: [
      pdt8,
      pdt8
    ],
    name: "Lunch Box Combo",
    address: "Kampala, mukono, Uganda",
    price: 19500,
    details: [
      "5 hot wings",
      "chips",
      "coleslow",
      "With a Coke",
    ],
    description:
    "it comes with chilli",
  },
  {
    id: 3,
    type: "Hot",
    mainImage: pdt9,
    moreImages: [
      pdt9,
      pdt9
    ],
    name: "Chicken Bucket with Thighs",
    address: "Kampala, mukono, Uganda",
    price: 60000,
    details: [
      "4 wings",
      "1 plate of chips",
      "4 thighs",
    ],
    description:
    "it comes with chilli",
  },
  {
    id: 4,
    type: "feature",
    mainImage: pdt,
    moreImages: [
      pdt,
      pdt
    ],
    name: "wings with pepsi",
    address: "Kampala, mukono, Uganda",
    price:10000,
    details: [
      "4 wings",
      "1 plate of chips",
      "4 thighs",
    ],
    description:
    "it comes with chilli",
  },
  {
    id: 5,
    type: "featured",
    mainImage: pdt21,
    moreImages: [
      pdt21,
      pdt21
    ],
    name: "Zinger Burger Box",
    address: "Kampala, mukono, Uganda",
    price: 40000,
    details: [
      "4 wings",
      "1 plate of chips",
      "4 thighs",
    ],
    description:
    "Hot and crispy | Boxed meals ",
  },
  {
    id: 6,
    type: "featured",
    mainImage: pdt,
    moreImages: [
      pdt,
      pdt
    ],
    name: "wings with pepsi",
    address: "Kampala, mukono, Uganda",
    price: 80000,
    details: [
      "4 wings",
      "1 plate of chips",
      "4 thighs",
    ],
    description:
    "it comes with chilli",
  },
  ];
