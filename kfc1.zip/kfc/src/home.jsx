import HomePage from "../components/home-page-components/homePage";

const Home = () => {
  useEffect(() => {
    document.title = "KFC";
  }, []);
  return <HomePage />;
};

export default Home;
